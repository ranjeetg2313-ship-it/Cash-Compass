package com.example.expensetrackersystem.fragments;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.expensetrackersystem.R;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ExpenseFragment extends Fragment {

    private EditText amountEditText, customCategoryEditText;
    private Button addExpenseButton, addCategoryButton;
    private Spinner categorySpinner;
    private PieChart pieChart;

    private FirebaseAuth auth;
    private DatabaseReference databaseReference, expenseReference;
    private ArrayAdapter<String> categoryAdapter;
    private ArrayList<String> categoriesList;
    private Map<String, Float> categoryExpenseMap;

    public ExpenseFragment() {
        // Required empty public constructor
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_expense, container, false);

        auth = FirebaseAuth.getInstance();
        String userId = auth.getCurrentUser().getUid();
        databaseReference = FirebaseDatabase.getInstance().getReference("users").child(userId).child("categories");
        expenseReference = FirebaseDatabase.getInstance().getReference("users").child(userId).child("expenses");

        amountEditText = view.findViewById(R.id.amountEditText);
        customCategoryEditText = view.findViewById(R.id.customCategoryEditText);
        addExpenseButton = view.findViewById(R.id.addExpenseButton);
        addCategoryButton = view.findViewById(R.id.addCategoryButton);
        categorySpinner = view.findViewById(R.id.categorySpinner);
        pieChart = view.findViewById(R.id.pieChart);

        categoriesList = new ArrayList<>();
        categoryAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_item, categoriesList);
        categoryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        categorySpinner.setAdapter(categoryAdapter);

        categoryExpenseMap = new HashMap<>();
        loadCategories();
        loadExpenses(); // Load the expenses and update the pie chart

        // Add custom category button click handler
        addCategoryButton.setOnClickListener(v -> {
            String newCategory = customCategoryEditText.getText().toString().trim();
            if (!newCategory.isEmpty()) {
                addCategoryToFirebase(newCategory);
            } else {
                Toast.makeText(getContext(), "Please enter a category name", Toast.LENGTH_SHORT).show();
            }
        });

        // Add expense button click handler
        addExpenseButton.setOnClickListener(v -> {
            String amount = amountEditText.getText().toString().trim();
            Object selectedCategory = categorySpinner.getSelectedItem();

            // Validate amount and category selection
            if (amount.isEmpty()) {
                Toast.makeText(getContext(), "Please enter an amount", Toast.LENGTH_SHORT).show();
                return;
            }

            if (selectedCategory == null || selectedCategory.toString().isEmpty()) {
                Toast.makeText(getContext(), "Please select a valid category", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                float parsedAmount = Float.parseFloat(amount); // Validate amount format
                String category = selectedCategory.toString();
                addExpenseToFirebase(parsedAmount, category);
            } catch (NumberFormatException e) {
                Toast.makeText(getContext(), "Invalid amount entered", Toast.LENGTH_SHORT).show();
            }
        });

        return view;
    }

    private void loadCategories() {
        // Load categories from Firebase
        databaseReference.get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                DataSnapshot snapshot = task.getResult();
                categoriesList.clear();
                if (snapshot.exists()) {
                    for (DataSnapshot categorySnapshot : snapshot.getChildren()) {
                        String categoryName = categorySnapshot.child("name").getValue(String.class);
                        if (categoryName != null) {
                            categoriesList.add(categoryName);
                        }
                    }
                }
                // Add default categories if none exist
                if (categoriesList.isEmpty()) {
                    addDefaultCategories();
                }
                categoryAdapter.notifyDataSetChanged();
            } else {
                Toast.makeText(getContext(), "Failed to load categories from Firebase", Toast.LENGTH_SHORT).show();
            }
        }).addOnFailureListener(e -> {
            Toast.makeText(getContext(), "Error loading categories: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        });
    }

    private void addDefaultCategories() {
        String[] defaultCategories = {"Food", "Transport", "Utilities"}; // Change default categories as per your requirement
        for (String category : defaultCategories) {
            addCategoryToFirebase(category);
        }
    }

    private void addCategoryToFirebase(String categoryName) {
        String categoryId = databaseReference.push().getKey();
        if (categoryId != null) {
            Map<String, Object> categoryData = new HashMap<>();
            categoryData.put("name", categoryName);
            databaseReference.child(categoryId).setValue(categoryData)
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            categoriesList.add(categoryName);  // Add new category to list
                            categoryAdapter.notifyDataSetChanged(); // Update the spinner
                            customCategoryEditText.setText(""); // Clear input field
                            Toast.makeText(getContext(), "Category added", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(getContext(), "Failed to add category", Toast.LENGTH_SHORT).show();
                        }
                    }).addOnFailureListener(e -> {
                        Toast.makeText(getContext(), "Error adding category: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    });
        }
    }

    private void addExpenseToFirebase(float amount, String category) {
        DatabaseReference expenseReference = FirebaseDatabase.getInstance().getReference("users")
                .child(auth.getCurrentUser().getUid()).child("expenses");
        String expenseId = expenseReference.push().getKey();
        if (expenseId != null) {
            Map<String, Object> expenseData = new HashMap<>();
            expenseData.put("amount", amount);
            expenseData.put("category", category);

            expenseReference.child(expenseId).setValue(expenseData)
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            // Update the pie chart after adding the expense
                            updateExpenseData(category, amount);
                            updatePieChart();
                            Toast.makeText(getContext(), "Expense added", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(getContext(), "Failed to add expense", Toast.LENGTH_SHORT).show();
                        }
                    }).addOnFailureListener(e -> {
                        Toast.makeText(getContext(), "Error adding expense: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    });
        }
    }

    private void loadExpenses() {
        // Load expenses from Firebase and update the pie chart
        expenseReference.get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                DataSnapshot snapshot = task.getResult();
                categoryExpenseMap.clear();
                if (snapshot.exists()) {
                    for (DataSnapshot expenseSnapshot : snapshot.getChildren()) {
                        String category = expenseSnapshot.child("category").getValue(String.class);
                        Float amount = expenseSnapshot.child("amount").getValue(Float.class);
                        if (category != null && amount != null) {
                            updateExpenseData(category, amount);
                        }
                    }
                }
                updatePieChart(); // Update the pie chart with the loaded data
            }
        }).addOnFailureListener(e -> {
            Toast.makeText(getContext(), "Error loading expenses: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        });
    }

    private void updateExpenseData(String category, float amount) {
        // Update the expense data in the categoryExpenseMap
        if (categoryExpenseMap.containsKey(category)) {
            categoryExpenseMap.put(category, categoryExpenseMap.get(category) + amount);
        } else {
            categoryExpenseMap.put(category, amount);
        }
    }

    private void updatePieChart() {
        // Create entries for the pie chart
        List<PieEntry> entries = new ArrayList<>();
        for (Map.Entry<String, Float> entry : categoryExpenseMap.entrySet()) {
            entries.add(new PieEntry(entry.getValue(), entry.getKey()));
        }

        // Set data for the pie chart
        PieDataSet dataSet = new PieDataSet(entries, "Expense Categories");
        dataSet.setColors(new int[]{Color.RED, Color.GREEN, Color.BLUE, Color.MAGENTA, Color.CYAN}); // Set colors
        PieData pieData = new PieData(dataSet);

        pieChart.setData(pieData);
        pieChart.invalidate(); // Refresh the chart
    }
}
