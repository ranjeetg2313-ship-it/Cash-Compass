package com.example.expensetrackersystem.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.expensetrackersystem.R;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class IncomeFragment extends Fragment {

    private EditText amountEditText, customCategoryEditText;
    private Button addIncomeButton, addCategoryButton;
    private Spinner categorySpinner;
    private PieChart pieChart;  // PieChart for displaying categorized income

    private FirebaseAuth auth;
    private DatabaseReference databaseReference;
    private ArrayAdapter<String> categoryAdapter;
    private ArrayList<String> categoriesList;
    private Map<String, Float> incomeByCategory;  // Store income totals by category

    public IncomeFragment() {
        // Required empty public constructor
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_income, container, false);

        auth = FirebaseAuth.getInstance();
        String userId = auth.getCurrentUser().getUid();
        databaseReference = FirebaseDatabase.getInstance().getReference("users").child(userId).child("categories");

        amountEditText = view.findViewById(R.id.amountEditText);
        customCategoryEditText = view.findViewById(R.id.customCategoryEditText);
        addIncomeButton = view.findViewById(R.id.addIncomeButton);
        addCategoryButton = view.findViewById(R.id.addCategoryButton);
        categorySpinner = view.findViewById(R.id.categorySpinner);
        pieChart = view.findViewById(R.id.pieChart);  // Initialize PieChart

        categoriesList = new ArrayList<>();
        categoryAdapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_item, categoriesList);
        categoryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        categorySpinner.setAdapter(categoryAdapter);

        incomeByCategory = new HashMap<>();  // Initialize income map

        // Load categories from Firebase
        loadCategories();

        // Add custom category button click handler
        addCategoryButton.setOnClickListener(v -> {
            String newCategory = customCategoryEditText.getText().toString().trim();
            if (!newCategory.isEmpty()) {
                addCategoryToFirebase(newCategory);
            } else {
                Toast.makeText(getContext(), "Please enter a category name", Toast.LENGTH_SHORT).show();
            }
        });

        // Add income button click handler
        addIncomeButton.setOnClickListener(v -> {
            String amount = amountEditText.getText().toString().trim();
            Object selectedCategory = categorySpinner.getSelectedItem();

            // Validate amount and category selection
            if (amount.isEmpty()) {
                Toast.makeText(getContext(), "Please enter an amount", Toast.LENGTH_SHORT).show();
                return;
            }

            if (selectedCategory == null || selectedCategory.toString().isEmpty()) {
                Toast.makeText(getContext(), "Please select a valid category", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                float parsedAmount = Float.parseFloat(amount); // Validate amount format
                String category = selectedCategory.toString();
                addIncomeToFirebase(parsedAmount, category);
            } catch (NumberFormatException e) {
                Toast.makeText(getContext(), "Invalid amount entered", Toast.LENGTH_SHORT).show();
            }
        });

        return view;
    }

    private void loadCategories() {
        // Load categories from Firebase
        databaseReference.get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                DataSnapshot snapshot = task.getResult();
                categoriesList.clear();
                if (snapshot.exists()) {
                    for (DataSnapshot categorySnapshot : snapshot.getChildren()) {
                        String categoryName = categorySnapshot.child("name").getValue(String.class);
                        if (categoryName != null) {
                            categoriesList.add(categoryName);
                        }
                    }
                }
                // Add default categories if none exist
                if (categoriesList.isEmpty()) {
                    addDefaultCategories();
                }
                categoryAdapter.notifyDataSetChanged();
            } else {
                Toast.makeText(getContext(), "Failed to load categories from Firebase", Toast.LENGTH_SHORT).show();
            }
        }).addOnFailureListener(e -> {
            Toast.makeText(getContext(), "Error loading categories: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        });

        // Load income by category and update the pie chart
        loadIncomeByCategory();
    }

    private void addDefaultCategories() {
        String[] defaultCategories = {"Salary", "Freelancing", "Investments"};
        for (String category : defaultCategories) {
            addCategoryToFirebase(category);
        }
    }

    private void addCategoryToFirebase(String categoryName) {
        String categoryId = databaseReference.push().getKey();
        if (categoryId != null) {
            Map<String, Object> categoryData = new HashMap<>();
            categoryData.put("name", categoryName);
            databaseReference.child(categoryId).setValue(categoryData)
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            categoriesList.add(categoryName);  // Add new category to list
                            categoryAdapter.notifyDataSetChanged(); // Update the spinner
                            customCategoryEditText.setText(""); // Clear input field
                            Toast.makeText(getContext(), "Category added", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(getContext(), "Failed to add category", Toast.LENGTH_SHORT).show();
                        }
                    }).addOnFailureListener(e -> {
                        Toast.makeText(getContext(), "Error adding category: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    });
        }
    }

    private void addIncomeToFirebase(float amount, String category) {
        DatabaseReference incomeReference = FirebaseDatabase.getInstance().getReference("users")
                .child(auth.getCurrentUser().getUid()).child("income");
        String incomeId = incomeReference.push().getKey();
        if (incomeId != null) {
            Map<String, Object> incomeData = new HashMap<>();
            incomeData.put("amount", amount);
            incomeData.put("category", category);

            incomeReference.child(incomeId).setValue(incomeData)
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            Toast.makeText(getContext(), "Income added", Toast.LENGTH_SHORT).show();
                            updateIncomeByCategory(amount, category);  // Update the pie chart
                        } else {
                            Toast.makeText(getContext(), "Failed to add income", Toast.LENGTH_SHORT).show();
                        }
                    }).addOnFailureListener(e -> {
                        Toast.makeText(getContext(), "Error adding income: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    });
        }
    }

    private void updateIncomeByCategory(float amount, String category) {
        if (incomeByCategory.containsKey(category)) {
            incomeByCategory.put(category, incomeByCategory.get(category) + amount);
        } else {
            incomeByCategory.put(category, amount);
        }
        updatePieChart();  // Update pie chart when income is added
    }

    private void loadIncomeByCategory() {
        DatabaseReference incomeReference = FirebaseDatabase.getInstance().getReference("users")
                .child(auth.getCurrentUser().getUid()).child("income");

        incomeReference.get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                DataSnapshot snapshot = task.getResult();
                incomeByCategory.clear();
                for (DataSnapshot incomeSnapshot : snapshot.getChildren()) {
                    float amount = incomeSnapshot.child("amount").getValue(Float.class);
                    String category = incomeSnapshot.child("category").getValue(String.class);

                    if (category != null) {
                        updateIncomeByCategory(amount, category);  // Aggregate income by category
                    }
                }
                updatePieChart();  // Initial update to the pie chart
            }
        });
    }

    private void updatePieChart() {
        List<PieEntry> entries = new ArrayList<>();

        // Populate entries from incomeByCategory map
        for (Map.Entry<String, Float> entry : incomeByCategory.entrySet()) {
            entries.add(new PieEntry(entry.getValue(), entry.getKey()));
        }

        PieDataSet dataSet = new PieDataSet(entries, "Income by Category");
        dataSet.setColors(ColorTemplate.MATERIAL_COLORS);  // Set chart colors

        PieData pieData = new PieData(dataSet);
        pieChart.setData(pieData);
        pieChart.invalidate();  // Refresh the chart
    }
}
