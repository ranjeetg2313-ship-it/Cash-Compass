package com.example.expensetrackersystem.fragments; // Adjust package as necessary

public interface OnDataAddedListener {
    void onIncomeDataAdded();
    void onExpenseDataAdded();
}
