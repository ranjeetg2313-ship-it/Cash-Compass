package com.example.expensetrackersystem.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.expensetrackersystem.LoginActivity;
import com.example.expensetrackersystem.R;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class DashboardFragment extends Fragment {

    private BarChart barChart;
    private TextView tvIncome, tvExpense;
    private FirebaseAuth auth;
    private DatabaseReference databaseReference;

    public DashboardFragment() {
        // Required empty public constructor
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_dashboard, container, false);

        // Initialize UI components
        barChart = view.findViewById(R.id.barChart);
        tvIncome = view.findViewById(R.id.tv_income);
        tvExpense = view.findViewById(R.id.tv_expense);

        // Initialize Firebase authentication
        auth = FirebaseAuth.getInstance();
        FirebaseUser currentUser = auth.getCurrentUser();

        if (currentUser != null) {
            String userId = currentUser.getUid();  // Get current user ID
            databaseReference = FirebaseDatabase.getInstance().getReference("users").child(userId);

            // Load and display total income and expenses
            loadIncomeAndExpenses();
            setupBarChart();
        } else {
            // If no user is logged in, show an error and redirect to LoginActivity
            Toast.makeText(getContext(), "Please log in to view the dashboard", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(getContext(), LoginActivity.class));
            getActivity().finish();
        }

        return view;
    }

    private void loadIncomeAndExpenses() {
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                double totalIncome = 0;
                double totalExpense = 0;

                // Aggregate total income
                for (DataSnapshot snapshot : dataSnapshot.child("income").getChildren()) {
                    Double amount = snapshot.child("amount").getValue(Double.class);
                    if (amount != null) {
                        totalIncome += amount;
                    }
                }

                // Aggregate total expenses
                for (DataSnapshot snapshot : dataSnapshot.child("expenses").getChildren()) {
                    Double amount = snapshot.child("amount").getValue(Double.class);
                    if (amount != null) {
                        totalExpense += amount;
                    }
                }

                // Update the UI
                tvIncome.setText("Rs. " + totalIncome);
                tvExpense.setText("Rs. " + totalExpense);

                // Update the bar chart with two bars (one for income and one for expenses)
                updateBarChart(totalIncome, totalExpense);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("DashboardFragment", "Failed to load data: " + error.getMessage());
            }
        });
    }

    private void setupBarChart() {
        barChart.getDescription().setEnabled(false);
        barChart.getAxisLeft().setDrawGridLines(false);
        barChart.getXAxis().setDrawGridLines(false);
        barChart.getXAxis().setPosition(XAxis.XAxisPosition.BOTTOM);
        barChart.getAxisRight().setEnabled(false);
        barChart.getXAxis().setGranularity(1f);

        List<String> labels = new ArrayList<>();
        labels.add("Income");
        labels.add("Expense");
        barChart.getXAxis().setValueFormatter(new IndexAxisValueFormatter(labels));
    }

    private void updateBarChart(double totalIncome, double totalExpense) {
        List<BarEntry> entries = new ArrayList<>();
        entries.add(new BarEntry(0, (float) totalIncome));  // Bar for income
        entries.add(new BarEntry(1, (float) totalExpense)); // Bar for expense

        BarDataSet dataSet = new BarDataSet(entries, "Income vs Expense");
        dataSet.setColors(ColorTemplate.COLORFUL_COLORS);

        BarData data = new BarData(dataSet);

        // Animate the chart to smoothly increase the bar height
        barChart.setData(data);
        barChart.animateY(1000);  // 1-second animation for Y axis
        barChart.invalidate();  // Refresh chart
    }
}
