package com.example.expensetrackersystem.model;

public class SavingModel {
    private String id;
    private String amount;
    private String note;
    private String date;

    public SavingModel() { }

    public SavingModel(String id, String amount, String note, String date) {
        this.id = id;
        this.amount = amount;
        this.note = note;
        this.date = date;
    }

    // Getters and Setters
}
