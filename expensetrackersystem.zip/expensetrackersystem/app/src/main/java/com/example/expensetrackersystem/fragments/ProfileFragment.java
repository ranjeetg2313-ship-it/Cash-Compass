package com.example.expensetrackersystem.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.Spanned;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.expensetrackersystem.R;
import com.example.expensetrackersystem.LoginActivity;
import com.example.expensetrackersystem.AboutActivity; // Make sure to import AboutActivity
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class ProfileFragment extends Fragment {

    private EditText nameEditText, ageEditText;
    private TextView emailTextView;
    private Button logoutButton, aboutButton, saveButton;

    private FirebaseAuth auth;
    private DatabaseReference profileRef;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        // Initialize Firebase Auth
        auth = FirebaseAuth.getInstance();
        String userId = auth.getCurrentUser().getUid();
        profileRef = FirebaseDatabase.getInstance().getReference("users").child(userId); // Reference to the user's data

        // Find UI elements
        nameEditText = view.findViewById(R.id.nameEditText);
        ageEditText = view.findViewById(R.id.ageEditText);
        emailTextView = view.findViewById(R.id.emailTextView);
        logoutButton = view.findViewById(R.id.logoutButton);
        aboutButton = view.findViewById(R.id.aboutButton);
        saveButton = view.findViewById(R.id.saveButton);

        // Set input filters
        setInputFilters();

        // Load the user's profile from Firebase
        loadUserProfile();

        // Logout button action
        logoutButton.setOnClickListener(v -> {
            auth.signOut();
            Toast.makeText(getContext(), "Logged out successfully", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(getContext(), LoginActivity.class));
            getActivity().finish(); // Close current activity
        });

        // About button action
        aboutButton.setOnClickListener(v -> {
            // Start the AboutActivity
            Intent intent = new Intent(getActivity(), AboutActivity.class);
            startActivity(intent);
        });

        // Save button action
        saveButton.setOnClickListener(v -> {
            updateUserProfile();
        });

        return view;
    }

    private void setInputFilters() {
        // Filter for name: allows only letters and spaces
        InputFilter nameFilter = (source, start, end, dest, dstart, dend) -> {
            for (int i = start; i < end; i++) {
                if (!Character.isLetter(source.charAt(i)) && !Character.isSpaceChar(source.charAt(i))) {
                    return ""; // Reject the character
                }
            }
            return null; // Accept the input
        };

        // Filter for age: allows only digits
        InputFilter ageFilter = (source, start, end, dest, dstart, dend) -> {
            for (int i = start; i < end; i++) {
                if (!Character.isDigit(source.charAt(i))) {
                    return ""; // Reject the character
                }
            }
            return null; // Accept the input
        };

        nameEditText.setFilters(new InputFilter[]{nameFilter});
        ageEditText.setFilters(new InputFilter[]{ageFilter});
    }

    private void loadUserProfile() {
        profileRef.get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                DataSnapshot snapshot = task.getResult();
                if (snapshot.exists()) {
                    String name = snapshot.child("name").getValue(String.class);
                    String age = snapshot.child("age").getValue(String.class);
                    String email = snapshot.child("email").getValue(String.class);

                    // Set user profile details in TextViews
                    nameEditText.setText(name != null ? name : "N/A");
                    ageEditText.setText(age != null ? age : "N/A");
                    emailTextView.setText(email != null ? email : "N/A");
                } else {
                    Toast.makeText(getContext(), "No profile found", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(getContext(), "Failed to load profile", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void updateUserProfile() {
        String updatedName = nameEditText.getText().toString().trim();
        String updatedAge = ageEditText.getText().toString().trim();

        // Validation for name
        if (updatedName.isEmpty()) {
            Toast.makeText(getContext(), "Please enter your name", Toast.LENGTH_SHORT).show();
            return;
        } else if (updatedName.length() < 2) {
            Toast.makeText(getContext(), "Name must be at least 2 characters long", Toast.LENGTH_SHORT).show();
            return;
        }

        // Validation for age
        if (updatedAge.isEmpty()) {
            Toast.makeText(getContext(), "Please enter your age", Toast.LENGTH_SHORT).show();
            return;
        }

        int age;
        try {
            age = Integer.parseInt(updatedAge);
            if (age < 1 || age > 120) { // Assuming a realistic age range
                Toast.makeText(getContext(), "Please enter a valid age (1-120)", Toast.LENGTH_SHORT).show();
                return;
            }
        } catch (NumberFormatException e) {
            Toast.makeText(getContext(), "Age must be a number", Toast.LENGTH_SHORT).show();
            return;
        }

        // Update the user profile in Firebase
        profileRef.child("name").setValue(updatedName);
        profileRef.child("age").setValue(updatedAge).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                Toast.makeText(getContext(), "Profile updated successfully", Toast.LENGTH_SHORT).show();
                loadUserProfile(); // Refresh the displayed data
            } else {
                Toast.makeText(getContext(), "Failed to update profile", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
